# Starting prompt for Claude Code

Open Claude Code inside `prototype\sada` and paste the block below as the first message. CLAUDE.md is loaded
automatically; the prompt makes Claude verify the environment, build a mental model, and propose the first sprint
before touching anything.

---

You are joining an existing codebase. CLAUDE.md and the docs it imports describe the project, invariants,
conventions and roadmap. Do the following, in order, and report in Arabic (keep code and commits in English):

1. **Orient.** Read CLAUDE.md, docs/ARCHITECTURE.md, docs/DOMAIN.md, docs/USE_CASES.md, docs/AI_SERVICE.md,
   docs/ROADMAP.md, docs/DECISIONS.md, docs/DESIGN_SYSTEM.md. Then skim `backend/app/services/ledger.py`,
   `backend/app/services/transfers.py`, `backend/app/services/risk.py`, `backend/app/services/cases.py`,
   `ai-service/app/main.py`, `frontend/src/pages/Transfers.tsx`. Summarize in ≤ 15 lines how a held transfer
   travels from `POST /transfers` to a reviewer's decision, naming the functions involved. If anything in the
   docs contradicts the code, list it — do not fix yet.

2. **Verify the environment.** Create venvs and install requirements for `backend/` and `ai-service/`, run
   `npm install` in `frontend/`. Run `python -m pytest -q` in both Python services and `npm run build` in the
   frontend. Report exact results. If something fails, fix the environment (not the tests) and explain.

3. **Initialize git** if `.git` is missing: `git init`, sensible `.gitignore` is already there, first commit
   `chore: import Sada prototype (backend, ai-service, frontend, docs)`.

4. **Propose sprint 1** from docs/ROADMAP.md P0 items as a numbered plan with acceptance criteria and the files
   you expect to touch. Keep it to what fits in one working week for two students. Recommend an order and say why.
   Stop and wait for my approval before implementing.

Rules for everything after approval:
- Work in small commits, one roadmap item per branch, tests updated with every behavior change, docs updated in
  the same commit when behavior or contracts change.
- Never break the invariants in CLAUDE.md. If a task seems to require it, stop and ask.
- Before claiming something works, run it (tests, build, a curl against the running service, or a Playwright
  walk-through for UI).
- Ask me only when a wrong guess would be expensive; otherwise decide, state the assumption, and proceed.

---

## Useful follow-up prompts
- "نفّذ البند 1 من sprint 1 (التسجيل من المتصفح). ابدأ باختبار Playwright يفشل، ثم نفّذ، ثم شغّل الاختبار."
- "اكتب notebook تحضير البيانات حسب docs/AI_SERVICE.md، استورد features.py من الخدمة، وصدّر manifests."
- "راجع backend/app/services/ledger.py كمهندس مالي: أي سيناريو تزامن ممكن يخرق التوازن؟ اكتب اختباراً له."
- "جهّز سكربت العرض للجنة: Playwright يمشي سيناريو docs/USE_CASES.md ويلتقط صوراً لكل خطوة."
