# Sada (صدى) — project memory for Claude Code

Sada is a university semester project (Al-Sham Private University, Informatics Engineering, 2026–2027):
a **digital banking platform** whose customer-support channel has an integrated, explainable **voice-deepfake
screening feature**. The deepfake model is ONE feature inside a complete platform — the platform must be
fully functional and gradable even if the model never beats the baseline. Never let AI work block platform work.

Team: Mahmoud Al-Qawtali (project manager, backend/banking core, API) · Alhasan Al-Wasti (AI, data, call-center
module, frontend). Supervisors: Dr. Afaf Al-Shalabi, Dr. Yasser Al-Safadi. The user you talk to is Alhasan;
he writes in Levantine Arabic — answer in Arabic, keep code/comments/commits in English.

## Read these before non-trivial work
@docs/ARCHITECTURE.md
@docs/DOMAIN.md
@docs/USE_CASES.md
@docs/AI_SERVICE.md
@docs/ROADMAP.md
@docs/DECISIONS.md

## Repository layout
```
backend/     Sada Platform API — FastAPI, SQLAlchemy 2.0, Alembic, PostgreSQL (SQLite for tests/dev), port 8000
ai-service/  Sada AI — FastAPI, numpy/soundfile, optional PyTorch; own SQLite store; port 8100
frontend/    React 18 + TypeScript + Vite, RTL Arabic-first UI (Cairo font), port 5173, proxies /api -> 8000
docker-compose.yml  postgres + redis + ai + backend + frontend
start-dev.bat/.ps1  one-click local run on Windows (SQLite, three windows)
docs/        the documents imported above
```

## Commands
```bash
# backend
cd backend && python -m pytest -q                       # 15 tests, in-memory SQLite, fake AI client
SADA_DATABASE_URL=sqlite:///./var/dev.db python -m scripts.seed
uvicorn app.main:app --port 8000 --reload
alembic revision --autogenerate -m "msg" && alembic upgrade head   # Postgres only

# ai-service
cd ai-service && python -m pytest -q                    # 5 tests
uvicorn app.main:app --port 8100

# frontend
cd frontend && npm install && npm run dev               # build: npm run build (tsc -b && vite build)
```
Run the relevant test suite after every backend or ai-service change. `npm run build` must pass after frontend changes.

## Hard invariants (do not break; add a test if you touch them)
1. **Money moves only in `backend/app/services/ledger.py`.** Every posted LEDGER_TRANSACTION has balanced
   DEBIT/CREDIT entries. Accounts are locked in id order (`SELECT … FOR UPDATE` on Postgres) and balances are
   re-checked under the lock. Posted transactions are never edited; they are reversed via `reversal_of_id`.
2. **Held transfers** move money from `available_balance` to `frozen_balance` with NO ledger entries.
   Accept = post from frozen; reject = release hold. Both run inside the case decision transaction.
3. **One DB transaction per use case.** Services do the work and `commit()`; routers only translate errors.
   Audit rows (`services/audit.py`) are written inside the same transaction as the change they describe.
4. **The AI is optional at runtime.** `services/ai_client.py` turns any failure into an `UNAVAILABLE`
   assessment; the Risk Engine must still produce a decision without it. Never auto-reject on missing audio.
5. **No score for bad audio.** ai-service returns `INSUFFICIENT_QUALITY` / `INVALID_AUDIO` instead of a number.
   Every result carries `model_version`, `preprocess_version`, `threshold`. Scratch files are deleted on every path.
6. **Human decides.** Risk Engine output is PASS or MANUAL_REVIEW; the final decision on a case is a staff
   member's, with a mandatory rationale, recorded in AUDIT_LOG.
7. **Audio never lives in the database.** Encrypted retained copy in `SADA_EVIDENCE_DIR`, streamed only through
   `/cases/{id}/audio` (authorized + audited), deleted when the case is decided.
8. **REVIEW_CASE** references exactly one of `ticket_id` / `transfer_id` (CHECK constraint).

## Conventions
- Python: type hints, SQLAlchemy 2.0 `Mapped[...]` models, Pydantic v2 schemas in `backend/app/schemas.py`.
  Errors are raised as service exceptions (`TransferError`, `TicketError`, `CaseError`, `LedgerError`) with a
  `code` and translated to `{"code", "message"}` JSON by routers. User-facing messages are Arabic.
- HTTP semantics: 200 done · 201 created · 202 accepted-pending-review · 400 bad input · 401 auth/OTP ·
  403 role · 404 not found · 409 state conflict · 422 business rule violation.
- References shown to users: `TRF-YYYY-NNNNN`, `TKT-YYYY-NNNNN`, `REV-YYYY-NNNNN` (`services/references.py`); UUIDs are the PKs.
- Settings that staff may change live in SYSTEM_SETTING (`services/settings_store.py`), not in code.
- Frontend: plain CSS with tokens in `src/styles/global.css`, no UI framework. Numbers/latin ids get class `num`/`mono`
  (LTR isolate). Status chips show code + Arabic label. Arabic copy follows the Figma kit tone (calm, no alarmism).
- Tests mirror use cases (`tests/test_uc01_transfer.py`, `tests/test_uc02_uc04_cases.py`). New behavior → new test.
- Commits: `type(scope): summary` e.g. `feat(backend): webhook signing`. Small, focused commits.

## Current status (2026-11-18)
Done: all 14 ERD tables; UC-01 (transfer + OTP + risk hold) · UC-02 (sensitive request with audio) ·
UC-03 (AI pipeline with stub classifier) · UC-04 (review + settle/cancel + audio retention); admin API
(settings, users/roles, audit, ledger, reverse); frontend: auth, home, transfers, support, review queue, case screen.
Not done: live browser recording / WebRTC call, admin screens, model training + checkpoint, HMAC webhooks,
Redis queue workers, Arabic/English toggle. See docs/ROADMAP.md for priorities and acceptance criteria.

## Working style with the user
- Start by stating the plan in 3–5 lines, then execute. Ask only when a wrong guess is expensive.
- Direct answers, no filler, no flattery. Flag assumptions and real problems explicitly.
- When you change behavior, update the matching doc under `docs/` in the same change.
